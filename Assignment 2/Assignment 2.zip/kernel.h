//
// Created by antler on 2020-02-29.
//
void myinit(const char* path);
void scheduler();