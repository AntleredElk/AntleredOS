Personal Linux Ubuntu machine was used for the assignment (Not SSH)
