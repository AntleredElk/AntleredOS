Edward Latulipe-Kang (260746475) a linux operating system was used
