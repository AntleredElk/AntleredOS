//
// Created by antler on 2020-01-29.
//

void parseArgument(char *argument);