//
// Created by antler on 2020-01-28.
//

void interpreter(char *command, int nbrOfArguments, char **arguments);


