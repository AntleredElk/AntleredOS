//
// Created by antler on 2020-01-28.
//

void store(char* argument1, char* argument2);
void retrieve(char* argument1);

